var nodemailer = require('nodemailer');
route.post('/email',(req,res)=>{
  
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'varunrajaurya1996@gmail.com',
      pass: ''
    }
  });
  
  var mailOptions = {
    from: 'varunrajaurya1996@gmail.com',
    to: 'varun.rajaurya@mail.vinove.com',
    subject: 'Sending Email using Node.js',
    html: '<h1>Hey Rahul</h1><p>My Firt mail!</p>'
  };
  
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  
  });
})
