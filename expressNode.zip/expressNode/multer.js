var express = require('express');
var multer = require('multer');
var path = require('path');

var storage = multer.diskStorage({
    destination: './public/uploads',
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

var upload = multer({
    storage: storage,
    limits: { fileSize: 10000 },
    fileFilter: (req, file, cb) => {
        checkFileType(file, cb)
    }
}).single('single');

checkFileType = (file, cb) => {
    let filetypes = /txt|html|pdf|doc/;
    let extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    let mimetype = filetypes.test(file.mimetype);
    if (mimetype || extname) {
        return cb(null, true);
    } else {
        cb('Error: ' + filetypes + ' only')
    }
}

var app = express();

app.set('view engine', 'pug');
app.set('views', './views');

app.use(express.static('./public'));

app.get('/', (req, res) => res.render('multer'));

app.post('/upload', (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            res.render('multer', {
                msg: err,
            });
        }
        else {
            if (req.file === undefined) {
                res.render('multer', {
                    msg: 'ERROR: No File Selected'
                });
            } else {
                res.render('multer', {
                    msg: 'File Uploaded Successfully',
                    file:`uploads/${req.file.filename}`
                })
                console.log(req.file);
            }
        };
    });
});
app.listen(8080);